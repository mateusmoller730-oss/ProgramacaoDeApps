export class colaborador{
    constructor(nome, matricula, setor){
    this.nome = nome;
    this.matricula = matricula
}