export class ferrramenta {
    constructor(codigo, descricao, estado){
        this.codigo = codigo;
        this.descricao = descricao
        this.estado = estado
    }
}