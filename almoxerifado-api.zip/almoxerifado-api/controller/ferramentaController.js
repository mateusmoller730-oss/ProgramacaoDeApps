 import { Ferramenta } from "../model/Ferramenta.js";

import {
    cadastrar,
    listar,
    buscarPorIndice,
    atualizar,
    deletar
} from "../repository/ferramentaRepository.js";

export function cadastrarFerramenta(codigo, descricao, estado) {
    const ferramenta = new Ferramenta(codigo, descricao, estado);
    return cadastrar(ferramenta);
}

export function listarFerramentas() {
    return listar();
}

export function buscarFerramentaPorIndice(indice) {
    const ferramenta = buscarPorIndice(indice);

    if (ferramenta === undefined) {
        return { status: 404, mensagem: "Ferramenta não encontrada" };
    }

    return { status: 200, ferramenta };
}

export function atualizarFerramenta(indice, codigo, descricao, estado) {
    const ferramenta = buscarPorIndice(indice);

    if (ferramenta === undefined) {
        return { status: 404, mensagem: "Ferramenta não encontrada" };
    }

    const novaFerramenta = new Ferramenta(codigo, descricao, estado);

    atualizar(indice, novaFerramenta);

    return { status: 200, mensagem: "Ferramenta atualizada", ferramenta: novaFerramenta };
}

export function deletarFerramenta(indice) {
    const ferramenta = buscarPorIndice(indice);

    if (ferramenta === undefined) {
        return { status: 404, mensagem: "Ferramenta não encontrada" };
    }

    deletar(indice);

    return { status: 200, mensagem: "Ferramenta deletada" };
}